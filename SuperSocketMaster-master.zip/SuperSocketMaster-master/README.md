# SuperSocketMaster
Event Driven Java Socket Wrapper to help high school Java programmers easily send and receive text over a network

This is a Swing/AWT based class that uses ActionEvent to inform the GUI of any incoming text

This class allows you to create a server object that listens for incoming client connections.

Once a connection is made, a socket object is created and connects to the clinet

This class also allows you to create a client object that creates a socket object that connects to the server

The nettest.java file is included to demo the SuperSocketMaster class

I also hope to use this as an example repository for my students to demonstrate code versioning and collaborative programming

The Javadoc for this class can be found here:
http://staugustinechs.ca/SuperSocketMaster
